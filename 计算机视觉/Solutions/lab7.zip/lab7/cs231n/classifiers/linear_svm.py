
from builtins import range
import numpy as np
from random import shuffle

def svm_loss_naive(W, X, y, reg):
    """
    结构化的 SVM 损失函数，朴素实现（使用循环）。

    输入数据的维度为 D，共有 C 个类别，我们对大小为 N 的小批量数据进行操作。

    输入：
    - W：一个形状为 (D, C) 的 numpy 数组，包含权重。
    - X：一个形状为 (N, D) 的 numpy 数组，包含一个小批量的数据。
    - y：一个形状为 (N,) 的 numpy 数组，包含训练标签；y[i] = c 表示
      X[i] 的标签是 c，其中 0 <= c < C。
    - reg：(float) 正则化强度

    返回一个元组：
    - 损失值，一个单一的浮点数
    - 关于权重 W 的梯度；一个与 W 形状相同的数组
    """
    dW = np.zeros(W.shape)  # 将梯度初始化为零

    # 计算损失和梯度
    num_classes = W.shape[1]
    num_train = X.shape[0]
    loss = 0.0
    for i in range(num_train):
        scores = X[i].dot(W)
        correct_class_score = scores[y[i]]
        for j in range(num_classes):
            if j == y[i]:
                continue
            margin = scores[j] - correct_class_score + 1  # 注意 delta = 1
            if margin > 0:
                loss += margin
                # 正确分类的梯度减去 X[i]
                dW[:, y[i]] -= X[i].T
                # 错误分类的梯度加上 X[i]
                dW[:, j] += X[i].T

    # 目前损失是所有训练样本的总和，但我们希望它是平均值，因此我们除以 num_train。
    loss /= num_train

    # 添加正则化到损失中。
    loss += reg * np.sum(W * W)


    # 梯度同样处理
    dW /= num_train
    # 正则项的梯度
    dW += 2 * reg * W

    # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****

    return loss, dW


def svm_loss_vectorized(W, X, y, reg):
    """
    结构化的 SVM 损失函数，向量化实现。

    输入和输出与 svm_loss_naive 相同。
    """
    loss = 0.0
    dW = np.zeros(W.shape)  # 将梯度初始化为零

    # 实现结构化 SVM 损失的向量化版本，将结果存储在 loss 中。                     #

    num_classes = W.shape[1]
    num_train = X.shape[0]

    scores = X @ W
    # 获取对于每个 x 而言正确分类的分数
    scores_correct = scores[range(num_train), y].reshape((scores.shape[0], 1))
    # 对每个元素做 max(0, scores_error - scores_correct + 1) 操作，包括正确分类的元素
    # 统一操作后减少代码编写难度，只需要最后处理一下正确分类的分数，把它们变成 0 就行了
    margins = np.maximum(0, scores - scores_correct + 1)
    # 将正确分类的 margins 置为 0
    margins[range(num_train), y] = 0
    loss += np.sum(margins) / num_train
    loss += reg * np.sum(W * W)

    # 实现结构化 SVM 损失的梯度的向量化版本，将结果存储在 dW 中。                  #
    #                                                                           #
    # 提示：与其从头开始计算梯度，                                             #
    # 可能更容易的方法是重用你在计算损失时使用的一些中间值。                     #


    # 先把所有 margins > 0 的标记为 1 ，因为我们算梯度的时候并不需要用到具体的元素的损失是多少
    # 我们只想知道这个元素有没有被算进损失里面
    margins[margins > 0] = 1
    # 并且，对于每一个分类错误的元素而言，它对错误分类的 W 的梯度影响是 +X[i]
    # 它对正确分类的 W 的梯度影响是 -X[i]
    # 并且正确分类的分数位置我们是知道的
    # 因此我们只需要计算对于 X[i] 而言，有多少个分类 > 0，就代表错误分类的个数
    # 这个数量就是影响了梯度的数量，并且我们已经把错误分类的位置记为了 1
    # 接下来我们只要做到在正确分类的位置减去错误分类的个数
    # 接下来是举例，一直我们一共有 10 个分类，对于 X[i] 而言，我们有 3 个分类正确，加上一个本来就是正确分类的分数
    # 那么剩下 6 个分类错误的，也就是错误分类的预估值 > 正确分类的预估值 - 1 的数量
    # 那么对于梯度而言，我们只需要对正确分类的梯度减去六个 X[i] 就行，错误分类的个数各自加上一个 X[i]，具体的结合矩阵的 shape
    row_sum = np.sum(margins, axis=1)
    margins[range(num_train), y] = -row_sum
    dW += np.dot(X.T, margins) / num_train + reg * W

    return loss, dW
