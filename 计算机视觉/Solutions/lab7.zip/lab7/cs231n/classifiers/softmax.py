from builtins import range
import numpy as np
from random import shuffle

# 此函数使用循环的方式实现Softmax损失函数
def softmax_loss_naive(W, X, y, reg):
    """
    Softmax损失函数，使用朴素（带循环）的实现方式

    输入数据的维度为D，共有C个类别，我们在包含N个样本的小批量数据上进行操作。

    输入参数:
    - W: 一个形状为 (D, C) 的numpy数组，包含权重。
    - X: 一个形状为 (N, D) 的numpy数组，包含小批量数据。
    - y: 一个形状为 (N,) 的numpy数组，包含训练标签；y[i] = c 表示
      X[i] 的标签为c，其中 0 <= c < C。
    - reg: (float) 正则化强度

    返回值为一个元组:
    - 损失值，为一个浮点数
    - 权重W的梯度；一个与W形状相同的数组
    """
    # 初始化损失和梯度为零
    loss = 0.0
    dW = np.zeros_like(W)


    # 使用显式循环计算Softmax损失及其梯度。
    # 将损失存储在loss中，梯度存储在dW中。如果不小心，
    # 很容易遇到数值不稳定的问题。不要忘记正则化！


    # 训练样本的数量
    num_train = X.shape[0]
    # 类别的数量
    num_classes = W.shape[1]
    for i in range(num_train):
        # 计算每个样本的得分
        scores = X[i] @ W
        # 对得分求指数，得到未归一化的概率
        scores = np.exp(scores)
        # 计算每个类别的概率
        p = scores / np.sum(scores)
        # 计算损失，使用负对数似然
        loss += -np.log(p[y[i]])

        # 计算梯度
        for k in range(num_classes):
            # 获取当前类别的概率
            p_k = p[k]
            # 判断当前类别是否为正确类别
            if k == y[i]:
                dW[:, k] += (p_k - 1) * X[i]
            else:
                dW[:, k] += p_k * X[i]

    # 处理正则化项
    loss /= num_train
    dW /= num_train
    loss += 0.5 * reg * np.sum(W * W)
    dW += reg * W



    return loss, dW

# 此函数使用向量化的方式实现Softmax损失函数
def softmax_loss_vectorized(W, X, y, reg):
    """
    Softmax损失函数，向量化版本

    输入和输出与softmax_loss_naive相同
    """
    # 初始化损失和梯度为零
    loss = 0.0
    dW = np.zeros_like(W)

    # 不使用显式循环计算Softmax损失及其梯度。
    # 将损失存储在loss中，梯度存储在dW中。如果不小心，
    # 很容易遇到数值不稳定的问题。不要忘记正则化！

    # 训练样本的数量
    num_train = X.shape[0]
    # 类别的数量
    num_classes = W.shape[1]

    # 计算所有样本的得分
    scores = X @ W
    # 对得分求指数，得到未归一化的概率
    scores = np.exp(scores)
    # 计算所有样本的概率
    p = scores / np.sum(scores, axis=1, keepdims=True)
    # 计算损失，使用负对数似然
    loss += np.sum(-np.log(p[range(num_train), y]))

    # 计算梯度，根据公式，对于正确类别，概率减1
    p[range(num_train), y] -= 1
    dW = X.T @ p

    # 处理正则化项
    loss /= num_train
    loss += 0.5 * reg * np.sum(W * W)

    dW /= num_train
    dW += reg * W


    return loss, dW