
from __future__ import print_function

from builtins import range
from builtins import object
import numpy as np
from ..classifiers.linear_svm import *
from ..classifiers.softmax import *



class LinearClassifier(object):
    def __init__(self):
        self.W = None

    def train(
        self,
        X,
        y,
        learning_rate=1e-3,
        reg=1e-5,
        num_iters=100,
        batch_size=200,
        verbose=False,
    ):
        """
        使用随机梯度下降训练这个线性分类器。

        输入：
        - X: 一个形状为 (N, D) 的 numpy 数组，包含训练数据；有 N 个训练样本，每个样本的维度为 D。
        - y: 一个形状为 (N,) 的 numpy 数组，包含训练标签；y[i] = c 表示
          X[i] 的标签是 0 <= c < C，其中 C 是类别数量。
        - learning_rate: (float) 优化的学习率。
        - reg: (float) 正则化强度。
        - num_iters: (整数) 优化时要执行的步数。
        - batch_size: (整数) 每一步使用的训练样本数量。
        - verbose: (布尔值) 如果为真，在优化过程中打印进度。

        输出：
        一个列表，包含每次训练迭代时损失函数的值。
        """
        num_train, dim = X.shape
        num_classes = (
            np.max(y) + 1
        )  # 假设 y 的取值范围是 0...K-1，其中 K 是类别数量
        if self.W is None:
            # 懒初始化 W
            self.W = 0.001 * np.random.randn(dim, num_classes)

        # 使用随机梯度下降优化 W
        loss_history = []
        for it in range(num_iters):

            choice_idxs = np.random.choice(num_train, batch_size)
            X_batch = X[choice_idxs]
            y_batch = y[choice_idxs]

            # 计算损失和梯度
            loss, grad = self.loss(X_batch, y_batch, reg)
            loss_history.append(loss)

            ########################
            #                      #
            #    Homework 1        #
            #                      #
            ########################

            #思考self.W ,learning_rate ,grad三者的关系
            self.W -= learning_rate * grad

            if verbose and it % 100 == 0:
                print("迭代 %d / %d：损失 %f" % (it, num_iters, loss))

        return loss_history

    def predict(self, X):
        """
        使用这个线性分类器训练得到的权重预测数据点的标签。

        输入：
        - X: 一个形状为 (N, D) 的 numpy 数组，包含训练数据；有 N 个训练样本，每个样本的维度为 D。

        返回：
        - y_pred: 对 X 中数据的预测标签。y_pred 是一个长度为 N 的一维数组，每个元素是一个整数，表示预测的类别。
        """
        y_pred = np.zeros(X.shape[0])

        scores = X @ self.W
        y_pred = np.argmax(scores, axis=1)

        # *****END OF YOUR CODE (DO NOT DELETE/MODIFY THIS LINE)*****
        return y_pred

    def loss(self, X_batch, y_batch, reg):
        """
        计算损失函数及其导数。
        子类将覆盖这个方法。

        输入：
        - X_batch: 一个形状为 (N, D) 的 numpy 数组，包含一个小批量的 N 个数据点；每个点的维度为 D。
        - y_batch: 一个形状为 (N,) 的 numpy 数组，包含小批量的标签。
        - reg: (float) 正则化强度。

        返回：一个元组，包含：
        - 损失值，一个单一的浮点数
        - 关于 self.W 的梯度；一个与 W 形状相同的数组
        """
        pass


class LinearSVM(LinearClassifier):
    """ 一个使用多分类 SVM 损失函数的子类 """

    def loss(self, X_batch, y_batch, reg):
        return svm_loss_vectorized(self.W, X_batch, y_batch, reg)


class Softmax(LinearClassifier):
    """ 一个使用 Softmax + 交叉熵损失函数的子类 """

    def loss(self, X_batch, y_batch, reg):
        return softmax_loss_vectorized(self.W, X_batch, y_batch, reg)