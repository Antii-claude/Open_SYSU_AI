from builtins import range
from builtins import object
import numpy as np


class KNearestNeighbor(object):
    """一个使用 L2 距离的 kNN 分类器"""

    def __init__(self):
        pass

    def train(self, X, y):
        """
        训练分类器。对于 k-最近邻算法来说，这仅仅是记住训练数据。

        输入：
        - X: 一个形状为 (num_train, D) 的 numpy 数组，包含训练数据，其中 num_train 是样本数量，D 是每个样本的维度。
        - y: 一个形状为 (N,) 的 numpy 数组，包含训练标签，其中 y[i] 是 X[i] 的标签。
        """
        self.X_train = X
        self.y_train = y

    def predict(self, X, k=1, num_loops=0):
        """
        使用这个分类器预测测试数据的标签。

        输入：
        - X: 一个形状为 (num_test, D) 的 numpy 数组，包含测试数据，其中 num_test 是样本数量，D 是每个样本的维度。
        - k: 用于投票决定预测标签的最近邻的数量。
        - num_loops: 决定使用哪种实现方式来计算训练点和测试点之间的距离。

        返回：
        - y: 一个形状为 (num_test,) 的 numpy 数组，包含测试数据的预测标签，其中 y[i] 是测试点 X[i] 的预测标签。
        """
        if num_loops == 0:
            dists = self.compute_distances_no_loops(X)
        elif num_loops == 1:
            dists = self.compute_distances_one_loop(X)
        elif num_loops == 2:
            dists = self.compute_distances_two_loops(X)
        else:
            raise ValueError("num_loops 的值无效：%d" % num_loops)

        return self.predict_labels(dists, k=k)

    def compute_distances_two_loops(self, X):
        """
        使用两层嵌套循环计算每个测试点与每个训练点之间的距离。

        输入：
        - X: 一个形状为 (num_test, D) 的 numpy 数组，包含测试数据。

        返回：
        - dists: 一个形状为 (num_test, num_train) 的 numpy 数组，其中 dists[i, j] 是第 i 个测试点与第 j 个训练点之间的欧几里得距离。
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):
            for j in range(num_train):

                # 计算第 i 个测试点与第 j 个训练点之间的 L2 距离，并将结果存储在 dists[i, j] 中。您不应使用维度循环，也不应使用 np.linalg.norm()。#

                dists[i, j] = np.sqrt(np.sum(np.power(X[i] - self.X_train[j], 2)))


        return dists

    def compute_distances_one_loop(self, X):
        """
        使用单层循环计算每个测试点与每个训练点之间的距离。

        输入/输出：与 compute_distances_two_loops 相同
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        for i in range(num_test):

            ########################
            #                      #
            #    EXERCISE 1        #
            #                      #
            ########################
            # 计算第 i 个测试点与所有训练点之间的 L2 距离，并将结果存储在 dists[i, :] 中。不要使用 np.linalg.norm()。#
            dists[i,:] = np.sqrt(np.sum(np.power(self.X_train - X[i],2),axis=1))

        return dists

    def compute_distances_no_loops(self, X):
        """
        不使用显式循环计算每个测试点与每个训练点之间的距离。

        输入/输出：与 compute_distances_two_loops 相同
        """
        num_test = X.shape[0]
        num_train = self.X_train.shape[0]
        dists = np.zeros((num_test, num_train))
        # 不使用任何显式循环，计算所有测试点与所有训练点之间的 L2 距离，并将结果存储在 dists 中。#
        #                                                                       #
        # 您应该仅使用基本的数组操作；特别是，您不应使用 scipy 中的函数，也不应使用 np.linalg.norm()。#


        tmp1 = np.sum(np.power(X, 2), axis=1).reshape((X.shape[0], 1))
        tmp2 = np.sum(np.power(self.X_train, 2), axis=1).reshape((self.X_train.shape[0], 1)).T
        dists = np.sqrt(-2 * (X @ self.X_train.T) + tmp1 + tmp2)

        return dists

    def predict_labels(self, dists, k=1):
        """
        给定一个测试点与训练点之间的距离矩阵，预测每个测试点的标签。

        输入：
        - dists: 一个形状为 (num_test, num_train) 的 numpy 数组，其中 dists[i, j] 是第 i 个测试点与第 j 个训练点之间的距离。

        返回：
        - y: 一个形状为 (num_test,) 的 numpy 数组，包含测试数据的预测标签，其中 y[i] 是测试点 X[i] 的预测标签。
        """
        num_test = dists.shape[0]
        y_pred = np.zeros(num_test)
        for i in range(num_test):
            # 一个长度为 k 的列表，存储第 i 个测试点的 k 个最近邻的标签。
            closest_y = []
            #########################################################################


            closest_y = self.y_train[np.argsort(dists[i])[:k]]
            # 现在您已经找到了 k 个最近邻的标签，您需要找到 closest_y 中最常见的标签。将这个标签存储在 y_pred[i] 中。如果出现平局，则选择较小的标签。#
            y_pred[i] = np.argmax(np.bincount(closest_y))

        return y_pred